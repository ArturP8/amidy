
package com.example.scroll;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 1; i <= 20; i++) {
            String buttonID = "button" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            Button button = findViewById(resID);
            int finalI = i;
            button.setOnClickListener(v -> {
                Toast.makeText(MainActivity.this, "Kliknięto Button " + finalI, Toast.LENGTH_SHORT).show();
            });
        }
    }
}
