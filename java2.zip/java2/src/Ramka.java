import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Ramka extends JFrame {
    public Ramka() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setSize(400, 300);
        setLayout(new BorderLayout(10, 10));

JPanel PanelGlowny = new JPanel(new GridLayout(2, 2, 5, 5));
JLabel etykietaUzytkownik = new JLabel("Użytkownik:");
JTextField poleUzytkownik = new JTextField(15);
JLabel etykietaHaslo = new JLabel("Hasło:");
JPasswordField poleHaslo = new JPasswordField(15);

        PanelGlowny.add(etykietaUzytkownik);
        PanelGlowny.add(poleUzytkownik);
        PanelGlowny.add(etykietaHaslo);
        PanelGlowny.add(poleHaslo);

        JPanel panelPrzyciski = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton przyciskZaloguj = new JButton("Zaloguj");
        JButton przyciskAnuluj = new JButton("Anuluj");
        panelPrzyciski.add(przyciskZaloguj);
        panelPrzyciski.add(przyciskAnuluj);
        PanelGlowny.setBorder(new EmptyBorder(10,10,10,10));
        add(PanelGlowny, BorderLayout.CENTER);
        add(panelPrzyciski, BorderLayout.SOUTH);
        pack();
setVisible(true);
    }

    public static void main(String[] args) {
        new Ramka();
    }
}
